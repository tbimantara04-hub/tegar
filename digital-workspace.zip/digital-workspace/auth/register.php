<?php
session_start();
// Assuming config.php sets up the database connection variable $conn
require_once '../config.php'; 

// If user is already logged in, redirect to the dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Initialize error message variable
$error = '';

// --- FORM PROCESSING LOGIC ---
// Check if the form was submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize form data
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];
    $token = isset($_POST['token']) ? trim($_POST['token']) : ''; // Get the token
    $terms = isset($_POST['terms']);
    
    // Define the required token
    $required_token = '8123';

    // Server-side validation
    if (empty($username) || empty($email) || empty($password) || empty($role)) {
        $error = "All fields are mandatory.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif ($password !== $confirm_password) {
        $error = "Password confirmation does not match.";
    } elseif (($role === 'admin' || $role === 'manager') && $token !== $required_token) {
        // New validation for token
        $error = "An invalid or missing verification token was provided for the selected role.";
    } elseif (!$terms) {
        $error = "You must agree to the Terms & Conditions.";
    } else {
        // Check if username or email already exists in the database
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username or Email is already registered.";
            $stmt->close();
        } else {
            // If all validations pass, proceed with registration
            $stmt->close(); // Close the checking statement
            
            // Hash the password for security
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Prepare the INSERT statement
            $insert_stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
            $insert_stmt->bind_param("ssss", $username, $email, $hashed_password, $role);

            if ($insert_stmt->execute()) {
                // On success, set a success message and redirect to the login page
                $_SESSION['success'] = "Account created successfully! Please log in.";
                header('Location: login.php');
                $insert_stmt->close();
                $conn->close();
                exit();
            } else {
                $error = "A server error occurred. Failed to register.";
            }
            $insert_stmt->close();
        }
    }
    // Close the connection if it's still open
    if ($conn) {
        $conn->close();
    }
}

// Get success message from session (if redirected from another page)
$success = '';
if (isset($_SESSION['success'])) {
    $success = $_SESSION['success'];
    unset($_SESSION['success']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/modern-styles.css"> 
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <div class="brand-logo">
                    <i class="fas fa-rocket"></i>
                    <span>Digital Workspace</span>
                </div>
                <p class="text-muted">Create your account to get started</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="needs-validation" novalidate>
                <div class="form-group mb-3">
                    <label for="username" class="form-label fw-semibold">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" required>
                        <div class="invalid-feedback">Please enter your username.</div>
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label for="email" class="form-label fw-semibold">Email</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                        <div class="invalid-feedback">Please enter a valid email address.</div>
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label for="password" class="form-label fw-semibold">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                        <div class="invalid-feedback">Please enter your password.</div>
                    </div>
                </div>
                <div class="form-group mb-4">
                    <label for="confirm_password" class="form-label fw-semibold">Confirm Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
                        <div class="invalid-feedback">Please confirm your password.</div>
                    </div>
                </div>
                <div class="form-group mb-4">
                    <label for="role" class="form-label fw-semibold">Role</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="" disabled selected>Select your role</option>
                        <option value="admin">Admin</option>
                        <option value="manager">Manager</option>
                        <option value="employee">Employee</option> </select>
                    <div class="invalid-feedback">Please select your role.</div>
                </div>

                <div class="form-group mb-4" id="token-field-wrapper" style="display: none;">
                    <label for="token" class="form-label fw-semibold">Verification Token</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                        <input type="text" class="form-control" id="token" name="token" placeholder="Enter verification token">
                        <div class="invalid-feedback">A token is required for this role.</div>
                    </div>
                </div>
                
                <div class="form-group mb-4">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="terms" name="terms" required>
                        <label class="form-check-label" for="terms">
                            I agree to the <a href="#" class="text-decoration-none text-primary fw-semibold">Terms and Conditions</a>
                        </label>
                        <div class="invalid-feedback">You must agree before submitting.</div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100 mb-3">
                    <i class="fas fa-user-plus me-2"></i>Create Account
                </button>
                <div class="text-center">
                    <p class="text-muted mb-0">
                        Already have an account? 
                        <a href="login.php" class="text-decoration-none text-primary fw-semibold">Sign in here</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Self-invoking function for Bootstrap validation
        (function () {
          'use strict'
          var forms = document.querySelectorAll('.needs-validation')
          Array.prototype.slice.call(forms)
            .forEach(function (form) {
              form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                  event.preventDefault()
                  event.stopPropagation()
                }
                form.classList.add('was-validated')
              }, false)
            })
        })();

        // NEW: Logic to show/hide the token field based on role selection
        document.addEventListener('DOMContentLoaded', function() {
            const roleSelect = document.getElementById('role');
            const tokenFieldWrapper = document.getElementById('token-field-wrapper');
            const tokenInput = document.getElementById('token');

            roleSelect.addEventListener('change', function() {
                // Show token field if role is 'admin' or 'manager'
                if (this.value === 'admin' || this.value === 'manager') {
                    tokenFieldWrapper.style.display = 'block';
                    tokenInput.required = true; // Make the field required
                } else {
                    // Hide token field for other roles
                    tokenFieldWrapper.style.display = 'none';
                    tokenInput.required = false; // Make it not required
                    tokenInput.value = ''; // Clear the value if the role is changed
                }
            });
        });
    </script>
</body>
</html>