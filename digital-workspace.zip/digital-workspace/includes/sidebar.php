<nav class="modern-sidebar">
    <div class="sidebar-header">
        <a href="../index.php" class="brand-logo">
            <i class="fas fa-rocket"></i>
            <span>Workspace</span>
        </a>
    </div>
    
    <div class="user-profile">
        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['username']); ?>&background=3b82f6&color=fff" alt="User" class="user-avatar">
        <div class="user-info">
            <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
            <div class="user-role"><?php echo htmlspecialchars($_SESSION['role']); ?></div>
        </div>
    </div>
    
    <ul class="sidebar-nav">
        <li class="nav-item">
            <a href="../index.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : ''; ?>">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="projects.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'projects.php') ? 'active' : ''; ?>">
                <i class="fas fa-project-diagram"></i>
                <span>Projects</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="tasks.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'tasks.php') ? 'active' : ''; ?>">
                <i class="fas fa-tasks"></i>
                <span>Tasks</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="files.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'files.php') ? 'active' : ''; ?>">
                <i class="fas fa-folder"></i>
                <span>Files</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="messages.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'messages.php') ? 'active' : ''; ?>">
                <i class="fas fa-comments"></i>
                <span>Messages</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="calendar.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'calendar.php') ? 'active' : ''; ?>">
                <i class="fas fa-calendar"></i>
                <span>Calendar</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="employees.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'employees.php') ? 'active' : ''; ?>">
                <i class="fas fa-users"></i>
                <span>Team</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="profile.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'profile.php') ? 'active' : ''; ?>">
                <i class="fas fa-user"></i>
                <span>Profile</span>
            </a>
        </li>
    </ul>
     <div class="sidebar-footer">
        <a href="../auth/logout.php" class="btn btn-danger w-100">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>
</nav>
