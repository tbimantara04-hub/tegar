// Modern Dashboard JavaScript
class ModernDashboard {
    constructor() {
        this.init();
    }

    init() {
        this.setupSidebar();
        this.setupSearch();
        this.setupNotifications();
        this.setupAnimations();
        this.setupThemeToggle();
        this.setupResponsive();
    }

    setupSidebar() {
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.querySelector('.modern-sidebar');
        const mainContent = document.querySelector('.main-content');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('collapsed');
                mainContent.classList.toggle('expanded');
                this.saveSidebarState();
            });
        }

        // Load saved sidebar state
        const savedState = localStorage.getItem('sidebarCollapsed');
        if (savedState === 'true') {
            sidebar.classList.add('collapsed');
            mainContent.classList.add('expanded');
        }
    }

    saveSidebarState() {
        const sidebar = document.querySelector('.modern-sidebar');
        const isCollapsed = sidebar.classList.contains('collapsed');
        localStorage.setItem('sidebarCollapsed', isCollapsed);
    }

    setupSearch() {
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.performSearch(e.target.value);
            });
        }
    }

    performSearch(query) {
        // Implement search functionality
        console.log('Searching for:', query);
        // This would typically filter content or make API calls
    }

    setupNotifications() {
        const notificationBtn = document.querySelector('.notification-btn');
        if (notificationBtn) {
            notificationBtn.addEventListener('click', () => {
                this.showNotifications();
            });
        }
    }

    showNotifications() {
        // Create notification dropdown
        const notifications = [
            { title: 'New task assigned', time: '2 min ago', type: 'task' },
            { title: 'File shared with you', time: '1 hour ago', type: 'file' },
            { title: 'Meeting reminder', time: '3 hours ago', type: 'meeting' }
        ];

        // Implementation would show a dropdown with notifications
        console.log('Showing notifications:', notifications);
    }

    setupAnimations() {
        // Intersection Observer for scroll animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        // Observe all cards and stat elements
        document.querySelectorAll('.modern-card, .stat-card').forEach(card => {
            observer.observe(card);
        });
    }

    setupThemeToggle() {
        // Check for saved theme preference
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-mode');
        }

        // Add theme toggle button
        this.createThemeToggle();
    }

    createThemeToggle() {
        const themeToggle = document.createElement('button');
        themeToggle.className = 'btn btn-light ms-2';
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        themeToggle.title = 'Toggle dark mode';
        
        themeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const isDark = document.body.classList.contains('dark-mode');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            themeToggle.innerHTML = `<i class="fas fa-${isDark ? 'sun' : 'moon'}"></i>`;
        });

        const headerRight = document.querySelector('.header-right');
        if (headerRight) {
            headerRight.insertBefore(themeToggle, headerRight.firstChild);
        }
    }

    setupResponsive() {
        // Handle window resize
        window.addEventListener('resize', () => {
            this.handleResponsive();
        });

        // Initial responsive check
        this.handleResponsive();
    }

    handleResponsive() {
        const sidebar = document.querySelector('.modern-sidebar');
        const mainContent = document.querySelector('.main-content');
        
        if (window.innerWidth <= 768) {
            sidebar.classList.add('collapsed');
            mainContent.classList.add('expanded');
        }
    }

    // Utility methods
    showLoading(element) {
        element.classList.add('loading');
    }

    hideLoading(element) {
        element.classList.remove('loading');
    }

    showToast(message, type = 'info') {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;

        const container = document.createElement('div');
        container.className = 'toast-container position-fixed top-0 end-0 p-3';
        container.appendChild(toast);
        document.body.appendChild(container);

        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();

        // Clean up after toast is hidden
        toast.addEventListener('hidden.bs.toast', () => {
            container.remove();
        });
    }

    // Update stats dynamically
    updateStats(stats) {
        const statElements = document.querySelectorAll('.stat-value');
        statElements.forEach((element, index) => {
            element.classList.add('fade-in');
        });
        // Implementation would update stats dynamically
        console.log('Updating stats:', stats);
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ModernDashboard();
});
