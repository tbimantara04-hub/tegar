# Copilot Instructions for Digital Workspace

## Project Overview
- This is a PHP-based web application for agency digital workspace management, using MySQL for data storage.
- Major components: authentication (`auth/`), configuration (`includes/config.php`), dashboard and navigation (`index.php`, `index-modern.php`), business logic pages (`pages/`), assets (`assets/`), and database schema (`database/workspace.sql`).

## Architecture & Data Flow
- All user/session management is handled via PHP sessions. Most pages require authentication and redirect to `auth/login.php` if not logged in.
- Database connection is established in `includes/config.php` and reused across pages via `require_once`.
- Data is stored in MySQL tables (`users`, `projects`, etc.), defined in `database/workspace.sql`.
- AJAX and POST requests are used for dynamic data (see `pages/projects.php` for examples of AJAX endpoints).
- UI is built with Bootstrap 5 and FontAwesome, with custom styles in `assets/css/modern-styles.css` and `assets/css/styles.css`.
- JavaScript for dashboard interactivity is in `assets/js/dashboard.js` and `assets/js/modern-dashboard.js`.

## Developer Workflows
- No build step required; code runs directly on PHP server (e.g., XAMPP).
- Database setup: import `database/workspace.sql` into MySQL.
- To debug, use browser dev tools and PHP error reporting (`ini_set('display_errors', 1); error_reporting(E_ALL);`).
- No automated tests or test runner detected; manual testing via browser is standard.

## Project-Specific Conventions
- All pages start with session checks and redirect unauthenticated users.
- Database queries use prepared statements for security.
- User info is accessed via `$_SESSION` variables (e.g., `$_SESSION['user_id']`, `$_SESSION['role']`).
- Navigation and sidebar structure is consistent across pages, with links to all major sections.
- AJAX endpoints are handled inline in page controllers (see `projects.php`).
- Modern UI uses a color palette and design tokens defined in `modern-styles.css`.

## Integration Points & External Dependencies
- Relies on Bootstrap CDN and FontAwesome CDN for UI.
- No external APIs or microservices detected; all logic is local.
- Avatar images use `ui-avatars.com` for dynamic generation.

## Key Files & Directories
- `includes/config.php`: DB connection, session, base URL.
- `auth/`: login, logout, registration logic.
- `pages/`: main business logic (projects, tasks, files, etc.).
- `assets/js/`: dashboard and UI scripts.
- `assets/css/`: design system and styles.
- `database/workspace.sql`: schema and table definitions.

## Example Patterns
- **Session Check:**
  ```php
  session_start();
  if (!isset($_SESSION['user_id'])) {
      header("Location: auth/login.php");
      exit();
  }
  ```
- **DB Query:**
  ```php
  $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
  $stmt->bind_param("s", $username);
  $stmt->execute();
  ```
- **AJAX Endpoint:**
  ```php
  if (isset($_POST['action'])) {
      // handle action
  }
  ```

---

If any conventions or workflows are unclear or missing, please provide feedback to improve these instructions.
