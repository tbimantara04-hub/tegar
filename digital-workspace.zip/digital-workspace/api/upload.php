<?php
session_start();
require_once '../config.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $description = $_POST['description'] ?? '';
    $uploaded_by = $_SESSION['user_id'];

    $file = $_FILES['file'];
    $original_name = $file['name'];
    $file_type = $file['type'];
    $file_size = $file['size'];
    $tmp_name = $file['tmp_name'];

    // Direktori untuk menyimpan file yang diunggah
    $upload_dir = '../uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Buat nama file yang unik untuk menghindari penimpaan
    $filename = uniqid() . '-' . basename($original_name);
    $destination = $upload_dir . $filename;

    // Pindahkan file yang diunggah ke direktori tujuan
    if (move_uploaded_file($tmp_name, $destination)) {
        // Simpan informasi file ke database
        $stmt = $conn->prepare("INSERT INTO files (filename, original_name, file_type, file_size, description, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssisi", $filename, $original_name, $file_type, $file_size, $description, $uploaded_by);

        if ($stmt->execute()) {
            // Redirect kembali ke halaman files setelah berhasil
            header("Location: ../pages/files.php");
            exit();
        } else {
            // Jika gagal menyimpan ke database, hapus file yang sudah diunggah
            unlink($destination);
            echo "Error: Gagal menyimpan informasi file ke database.";
        }
    } else {
        echo "Error: Gagal mengunggah file.";
    }
} else {
    // Jika bukan request POST atau tidak ada file yang diunggah
    header("Location: ../pages/files.php");
    exit();
}
?>
