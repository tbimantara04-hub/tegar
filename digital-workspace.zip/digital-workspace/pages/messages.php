<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
// Path ke config.php
require_once '../config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Messages - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link rel="stylesheet" href="../assets/css/modern-styles.css" />
    <style>
        .fab-container {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 1000;
        }
        #chatWindow {
            height: 55vh; /* Sedikit lebih tinggi untuk view yang lebih baik */
            overflow-y: auto;
        }
        /* CSS untuk bubble chat */
        .chat-message-left, .chat-message-right {
            display: flex;
            flex-shrink: 0;
        }
        .chat-message-right {
            flex-direction: row-reverse;
        }
        .list-group-item.active {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
    </style>
</head>
<body>
    <div class="modern-wrapper">
        <?php include '../includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="modern-header">
                <div class="header-left">
                    <button class="menu-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <h1 class="h4 mb-0">Messages</h1>
                </div>
                <?php include '../includes/header.php'; ?>
            </header>

            <div class="container-fluid p-4">
                <div class="card">
                    <div class="row g-0">
                        <div class="col-12 col-lg-4 col-xl-3 border-end">
                            <div class="px-4 py-3">
                                <h5 class="d-none d-md-block">Conversations</h5>
                            </div>
                            <div class="list-group list-group-flush border-top">
                                <?php
                                $userId = $_SESSION['user_id'];
                                // PERBAIKAN: Query untuk mengambil SEMUA user kecuali diri sendiri
                                $stmt = $conn->prepare("SELECT id, username FROM users WHERE id != ? ORDER BY username ASC");
                                $stmt->bind_param("i", $userId);
                                $stmt->execute();
                                $result = $stmt->get_result();
                                while ($user = $result->fetch_assoc()):
                                ?>
                                <a href="#" class="list-group-item list-group-item-action" data-user-id="<?php echo $user['id']; ?>">
                                    <div class="d-flex align-items-start">
                                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['username']); ?>&background=random" class="rounded-circle me-3" alt="User" width="40" height="40">
                                        <div class="flex-grow-1">
                                            <?php echo htmlspecialchars($user['username']); ?>
                                        </div>
                                    </div>
                                </a>
                                <?php endwhile; ?>
                            </div>
                        </div>
                        <div class="col-12 col-lg-8 col-xl-9 d-flex flex-column">
                            <div class="py-2 px-4 border-bottom d-none d-lg-block">
                                <h5 id="chat-username">Select a conversation</h5>
                            </div>
                            <div class="p-4 flex-grow-1" id="chatWindow">
                                <p class="text-center text-muted">Select a conversation to start chatting.</p>
                            </div>
                            <div class="py-3 px-4 border-top">
                                <form id="messageForm" class="input-group">
                                    <input type="text" id="messageInput" class="form-control" placeholder="Type your message" autocomplete="off" disabled>
                                    <button type="submit" class="btn btn-primary">Send</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/modern-dashboard.js"></script>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const conversationsList = document.querySelector('.list-group');
        const chatWindow = document.getElementById('chatWindow');
        const messageForm = document.getElementById('messageForm');
        const messageInput = document.getElementById('messageInput');
        const chatUsername = document.getElementById('chat-username');
        let currentChatUserId = null;
        let messagePolling = null; // Untuk real-time update

        // Fungsi untuk meng-scroll chat ke paling bawah
        function scrollToBottom() {
            chatWindow.scrollTop = chatWindow.scrollHeight;
        }

        conversationsList.addEventListener('click', function(e) {
            e.preventDefault();
            const target = e.target.closest('a.list-group-item');
            if (target) {
                document.querySelectorAll('a.list-group-item').forEach(item => item.classList.remove('active'));
                target.classList.add('active');
                
                currentChatUserId = target.getAttribute('data-user-id');
                const username = target.querySelector('.flex-grow-1').textContent.trim();
                chatUsername.textContent = `Chat with ${username}`;
                messageInput.disabled = false;
                messageInput.focus();
                
                loadMessages(currentChatUserId);

                // Menghentikan polling sebelumnya dan memulai yang baru untuk chat yang aktif
                if (messagePolling) clearInterval(messagePolling);
                messagePolling = setInterval(() => loadMessages(currentChatUserId), 3000); // Refresh setiap 3 detik
            }
        });

        messageForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (!currentChatUserId) return;
            const message = messageInput.value.trim();
            if (message === '') return;
            sendMessage(currentChatUserId, message);
            messageInput.value = '';
        });

        function loadMessages(userId) {
            fetch(`get_messages.php?user_id=${userId}`)
                .then(response => response.json())
                .then(messages => {
                    chatWindow.innerHTML = ''; // Kosongkan window chat
                    if (messages.length === 0) {
                        chatWindow.innerHTML = '<p class="text-center text-muted">No messages yet. Start the conversation!</p>';
                        return;
                    }
                    messages.forEach(msg => {
                        const messageElement = document.createElement('div');
                        const isSender = msg.sender_id == <?php echo $_SESSION['user_id']; ?>;
                        
                        let messageClass = isSender ? 'chat-message-right' : 'chat-message-left';
                        
                        messageElement.classList.add(messageClass, 'pb-4');
                        messageElement.innerHTML = `
                            <div>
                                <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(msg.username)}&background=random" class="rounded-circle me-1" alt="${msg.username}" width="40" height="40">
                                <div class="text-muted small text-nowrap mt-2">${new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                            </div>
                            <div class="flex-shrink-1 bg-light rounded py-2 px-3 ${isSender ? 'me-3 bg-primary text-white' : 'ms-3'}">
                                <div class="fw-bold mb-1">${isSender ? 'You' : msg.username}</div>
                                ${escapeHTML(msg.message_content)}
                            </div>
                        `;
                        chatWindow.appendChild(messageElement);
                    });
                    scrollToBottom();
                })
                .catch(error => {
                    console.error('Error loading messages:', error);
                    chatWindow.innerHTML = '<p class="text-center text-danger">Could not load messages.</p>';
                });
        }

        function sendMessage(userId, message) {
            const formData = new FormData();
            formData.append('receiver_id', userId);
            formData.append('message', message);

            fetch('send_message.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    loadMessages(userId); // Muat ulang pesan setelah berhasil terkirim
                } else {
                    console.error('Failed to send message:', data.message);
                }
            })
            .catch(error => console.error('Error sending message:', error));
        }
        
        // Fungsi untuk mencegah XSS (Cross-Site Scripting)
        function escapeHTML(str) {
            var p = document.createElement("p");
            p.appendChild(document.createTextNode(str));
            return p.innerHTML;
        }
    });
    </script>
</body>
</html>