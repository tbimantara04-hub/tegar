<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
// PERBAIKAN: Path ke config.php yang benar
require_once '../config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Messages - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <!-- PERBAIKAN: Menggunakan CSS yang konsisten -->
    <link rel="stylesheet" href="../assets/css/modern-styles.css" />
    <style>
        .fab-container {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 1000;
        }
        #chatWindow {
            height: 50vh;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="modern-wrapper">
        <!-- Memanggil Sidebar -->
        <?php include '../includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Memanggil Header -->
            <header class="modern-header">
                <div class="header-left">
                    <button class="menu-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <h1 class="h4 mb-0">Messages</h1>
                </div>
                <?php include '../includes/header.php'; ?>
            </header>

            <!-- Konten unik halaman -->
            <div class="container-fluid p-4">
                <div class="card">
                    <div class="row g-0">
                        <div class="col-12 col-lg-4 col-xl-3 border-end">
                            <div class="px-4 py-3">
                                <h5 class="d-none d-md-block">Conversations</h5>
                            </div>
                            <div class="list-group list-group-flush border-top">
                                <?php
                                $userId = $_SESSION['user_id'];
                                $stmt = $conn->prepare("SELECT DISTINCT u.id, u.username FROM users u JOIN messages m ON (u.id = m.sender_id OR u.id = m.receiver_id) WHERE u.id != ? AND (m.sender_id = ? OR m.receiver_id = ?) ORDER BY m.created_at DESC");
                                $stmt->bind_param("iii", $userId, $userId, $userId);
                                $stmt->execute();
                                $result = $stmt->get_result();
                                while ($user = $result->fetch_assoc()):
                                ?>
                                <a href="#" class="list-group-item list-group-item-action" data-user-id="<?php echo $user['id']; ?>">
                                    <div class="d-flex align-items-start">
                                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['username']); ?>&background=random" class="rounded-circle me-3" alt="User" width="40" height="40">
                                        <div class="flex-grow-1">
                                            <?php echo htmlspecialchars($user['username']); ?>
                                        </div>
                                    </div>
                                </a>
                                <?php endwhile; ?>
                            </div>
                        </div>
                        <div class="col-12 col-lg-8 col-xl-9">
                            <div class="py-2 px-4 border-bottom d-none d-lg-block">
                                <h5 id="chat-username">Select a conversation</h5>
                            </div>
                            <div class="p-4" id="chatWindow">
                                <p class="text-center text-muted">Select a conversation to start chatting.</p>
                            </div>
                            <div class="py-3 px-4 border-top">
                                <form id="messageForm" class="input-group">
                                    <input type="text" id="messageInput" class="form-control" placeholder="Type your message" autocomplete="off" disabled>
                                    <button type="submit" class="btn btn-primary">Send</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/modern-dashboard.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const conversationsList = document.querySelector('.list-group');
            const chatWindow = document.getElementById('chatWindow');
            const messageForm = document.getElementById('messageForm');
            const messageInput = document.getElementById('messageInput');
            const chatUsername = document.getElementById('chat-username');
            let currentChatUserId = null;

            conversationsList.addEventListener('click', function(e) {
                e.preventDefault();
                const target = e.target.closest('a.list-group-item');
                if (target) {
                    // Remove active class from all items
                    document.querySelectorAll('a.list-group-item').forEach(item => item.classList.remove('active'));
                    // Add active class to the clicked item
                    target.classList.add('active');
                    
                    currentChatUserId = target.getAttribute('data-user-id');
                    const username = target.querySelector('.flex-grow-1').textContent.trim();
                    chatUsername.textContent = `Chat with ${username}`;
                    messageInput.disabled = false;
                    loadMessages(currentChatUserId);
                }
            });

            messageForm.addEventListener('submit', function(e) {
                e.preventDefault();
                if (!currentChatUserId) return;
                const message = messageInput.value.trim();
                if (message === '') return;
                sendMessage(currentChatUserId, message);
                messageInput.value = '';
            });

            function loadMessages(userId) {
                chatWindow.innerHTML = '<p class="text-center">Loading messages...</p>';
                // This part should be replaced with an actual API call
                // For now, it's a placeholder
                setTimeout(() => {
                     chatWindow.innerHTML = '<p class="text-center text-muted">No messages yet.</p>';
                }, 500);
            }

            function sendMessage(userId, message) {
                // This part should be replaced with an actual API call
                console.log(`Sending message to ${userId}: ${message}`);
                loadMessages(userId); // Reload messages after sending
            }
        });
    </script>
</body>
</html>
