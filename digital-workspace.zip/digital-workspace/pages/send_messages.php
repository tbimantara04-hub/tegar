<?php
session_start();
require_once '../config.php'; // Sesuaikan path ke file config.php

if (!isset($_SESSION['user_id']) || !isset($_POST['receiver_id']) || !isset($_POST['message'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit();
}

$senderId = $_SESSION['user_id'];
$receiverId = $_POST['receiver_id'];
$message = trim($_POST['message']);

if (empty($message)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Message cannot be empty']);
    exit();
}

$stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message_content) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $senderId, $receiverId, $message);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Failed to send message']);
}
?>