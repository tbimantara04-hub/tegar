<?php
session_start();
require_once '../config.php';

header('Content-Type: application/json');

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    http_response_code(403); // Forbidden
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

// Validasi request
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['receiver_id']) || !isset($_POST['message'])) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit();
}

$sender_id = $_SESSION['user_id'];
$receiver_id = (int)$_POST['receiver_id'];
$message = trim($_POST['message']);

// Validasi isi pesan dan penerima
if (empty($message) || $receiver_id === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Message cannot be empty and receiver must be valid.']);
    exit();
}

// Masukkan pesan ke database menggunakan prepared statement
try {
    $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message_content) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $sender_id, $receiver_id, $message);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        throw new Exception("Statement execution failed.");
    }
    $stmt->close();
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Failed to send message.']);
}

$conn->close();
?>