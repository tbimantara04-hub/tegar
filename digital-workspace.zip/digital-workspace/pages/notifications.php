<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
require_once '../config.php';

// Di sini Anda akan mengambil semua notifikasi dari database
// PERBAIKAN: Menambahkan kunci 'link' ke setiap notifikasi
$notifications = [
    [
        'icon' => 'fa-project-diagram',
        'color' => 'text-primary',
        'title' => 'New project created',
        'body' => '"Website Redesign" was just created by Satria Tegar.',
        'time' => '15 minutes ago',
        'link' => 'projects.php' // Tautan ke halaman proyek
    ],
    [
        'icon' => 'fa-tasks',
        'color' => 'text-success',
        'title' => 'Task Completed',
        'body' => 'Sudiro Sigit completed the task "Review client report".',
        'time' => '1 hour ago',
        'link' => 'tasks.php' // Tautan ke halaman tugas
    ],
    [
        'icon' => 'fa-file-alt',
        'color' => 'text-warning',
        'title' => 'New File Uploaded',
        'body' => 'Tipando uploaded "Q4_Report.pdf".',
        'time' => '3 hours ago',
        'link' => 'files.php' // Tautan ke halaman file
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Notifications - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link rel="stylesheet" href="../assets/css/modern-styles.css" />
</head>
<body>
    <div class="modern-wrapper">
        <!-- Memanggil Sidebar -->
        <?php include '../includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Memanggil Header -->
            <header class="modern-header">
                <div class="header-left">
                    <button class="menu-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <h1 class="h4 mb-0">Notifications</h1>
                </div>
                <?php include '../includes/header.php'; ?>
            </header>

            <!-- Konten unik halaman -->
            <div class="container-fluid p-4">
                <div class="modern-card">
                    <div class="card-header">
                        <h5 class="card-title">All Notifications</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush">
                            <?php foreach ($notifications as $notification): ?>
                            <!-- PERBAIKAN: Menggunakan tautan dinamis dari array -->
                            <a href="<?php echo $notification['link']; ?>" class="list-group-item list-group-item-action d-flex align-items-start">
                                <i class="fas <?php echo $notification['icon']; ?> <?php echo $notification['color']; ?> me-3 mt-1 fa-lg"></i>
                                <div>
                                    <strong><?php echo $notification['title']; ?></strong>
                                    <div class="small text-muted"><?php echo $notification['body']; ?></div>
                                    <div class="small text-muted"><?php echo $notification['time']; ?></div>
                                </div>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/modern-dashboard.js"></script>
</body>
</html>