<?php
session_start();
// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
// Path yang benar ke config.php
require_once '../config.php';

// --- LOGIKA TAMBAH PROYEK ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_project'])) {
    $name = trim($_POST['project_name']);
    $description = trim($_POST['project_description']);
    $status = $_POST['project_status'];
    $created_by = $_SESSION['user_id'];

    if (!empty($name) && !empty($status)) {
        $stmt = $conn->prepare("INSERT INTO projects (name, description, status, created_by) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $name, $description, $status, $created_by);
        if ($stmt->execute()) {
            // Refresh halaman untuk melihat proyek baru
            header("Location: projects.php");
            exit();
        }
    }
}


// Handle search and filtering
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';

$query = "SELECT p.*, u.username as created_by_name FROM projects p LEFT JOIN users u ON p.created_by = u.id WHERE 1=1";
$params = [];
$types = "";

if (!empty($search)) {
    $query .= " AND p.name LIKE ?";
    $search_param = "%$search%";
    $params[] = $search_param;
    $types .= "s";
}

if (!empty($status_filter)) {
    $query .= " AND p.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

$query .= " ORDER BY p.created_at DESC";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$projects = $stmt->get_result();

// Variabel untuk menandai halaman aktif
$active_page = 'projects';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projects - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/modern-styles.css">
    <style>
        .fab-container {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div class="modern-wrapper">
        <!-- Memanggil Sidebar -->
        <?php include '../includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Memanggil Header -->
            <header class="modern-header">
                <div class="header-left">
                    <button class="menu-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <h1 class="h4 mb-0">Projects</h1>
                </div>
                <?php include '../includes/header.php'; ?>
            </header>

            <!-- Konten unik halaman -->
            <div class="container-fluid p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="h5 mb-0">All Projects</h2>
                </div>

                <div class="row">
                    <?php while ($project = $projects->fetch_assoc()): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title"><?php echo htmlspecialchars($project['name']); ?></h5>
                                <p class="card-text text-muted flex-grow-1"><?php echo htmlspecialchars(substr($project['description'], 0, 100)); ?>...</p>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="badge bg-info"><?php echo htmlspecialchars(ucfirst($project['status'])); ?></span>
                                    <small>By: <?php echo htmlspecialchars($project['created_by_name']); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>

            </div>
        </main>
    </div>

    <!-- Tombol Melayang (Floating Action Button) -->
    <div class="fab-container">
        <button class="btn btn-primary btn-lg rounded-circle" data-bs-toggle="modal" data-bs-target="#addProjectModal">
            <i class="fas fa-plus"></i>
        </button>
    </div>

    <!-- Modal Tambah Proyek -->
    <div class="modal fade" id="addProjectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Project</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="projects.php">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="projectName" class="form-label">Project Name</label>
                            <input type="text" class="form-control" id="projectName" name="project_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="projectDescription" class="form-label">Description</label>
                            <textarea class="form-control" id="projectDescription" name="project_description" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="projectStatus" class="form-label">Status</label>
                            <select class="form-select" id="projectStatus" name="project_status" required>
                                <option value="planning">Planning</option>
                                <option value="in_progress">In Progress</option>
                                <option value="completed">Completed</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_project" class="btn btn-primary">Create Project</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/modern-dashboard.js"></script>
    
    <!-- SCRIPT BARU UNTUK MENGAKTIFKAN SIDEBAR -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Hapus kelas 'active' dari semua item menu
            const menuItems = document.querySelectorAll('.sidebar .nav-link');
            menuItems.forEach(item => {
                item.classList.remove('active');
            });

            // Tambahkan kelas 'active' ke item menu Projects
            // Pastikan link di sidebar.php menuju ke 'projects.php'
            const projectsLink = document.querySelector('.sidebar .nav-link[href*="projects.php"]');
            if (projectsLink) {
                projectsLink.classList.add('active');
            }
        });
    </script>
</body>
</html>