
<?php
session_start();
// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

require_once '../config.php';

// Cek apakah request method adalah POST dan ada file yang diupload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    
    $file = $_FILES['file'];
    $description = $_POST['description'] ?? ''; // Ambil deskripsi dari form
    $uploaded_by = $_SESSION['user_id']; // Ambil user_id dari session

    // Direktori tujuan untuk menyimpan file
    $upload_dir = '../uploads/';
    
    // Pastikan direktori uploads ada, jika tidak, coba buat
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Ambil informasi file
    $original_name = $file['name'];
    $file_tmp_name = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    $file_type = $file['type'];

    // Cek jika ada error saat upload
    if ($file_error !== UPLOAD_ERR_OK) {
        // Handle error di sini, misalnya redirect dengan pesan error
        header("Location: files.php?error=uploadfailed");
        exit();
    }

    // Buat nama file yang unik untuk menghindari penimpaan file
    $new_filename = uniqid('file_', true) . '.' . $file_ext;
    $destination = $upload_dir . $new_filename;

    // Pindahkan file dari temporary location ke direktori tujuan
    if (move_uploaded_file($file_tmp_name, $destination)) {
        // Jika file berhasil dipindahkan, simpan informasinya ke database
        $stmt = $conn->prepare(
            "INSERT INTO files (original_name, filename, file_type, file_size, description, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("sssisi", $original_name, $new_filename, $file_type, $file_size, $description, $uploaded_by);
        
        if ($stmt->execute()) {
            // Jika berhasil disimpan ke DB, redirect kembali ke halaman files
            header("Location: files.php?success=uploaded");
            exit();
        } else {
            // Jika gagal simpan ke DB, hapus file yang sudah diupload dan beri pesan error
            unlink($destination);
            header("Location: files.php?error=dberror");
            exit();
        }
    } else {
        // Jika file gagal dipindahkan
        header("Location: files.php?error=movefailed");
        exit();
    }
} else {
    // Jika akses langsung atau tidak ada file
    header("Location: files.php");
    exit();
}
?>