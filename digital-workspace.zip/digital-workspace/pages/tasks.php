<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
require_once '../config.php';

$query = "SELECT t.*, p.name as project_name, u.username as assigned_to_name FROM tasks t LEFT JOIN projects p ON t.project_id = p.id LEFT JOIN users u ON t.assigned_to = u.id ORDER BY t.due_date ASC";
$tasks = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/modern-styles.css">
    <!-- Menambahkan CSS untuk tombol melayang -->
    <style>
        .fab-container {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div class="modern-wrapper">
        <!-- Modern Sidebar -->
        <?php include '../includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Modern Header -->
             <header class="modern-header">
                <div class="header-left">
                    <button class="menu-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <h1 class="h4 mb-0">Tasks</h1>
                </div>
                <?php include '../includes/header.php'; ?>
            </header>

            <!-- KONTEN UNIK HALAMAN DIMULAI DI SINI -->
            <div class="container-fluid p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="h5 mb-0">All Tasks</h2>
                </div>

                <div class="row">
                    <?php while ($task = $tasks->fetch_assoc()): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($task['title']); ?></h5>
                                <p class="card-text text-muted">Project: <?php echo htmlspecialchars($task['project_name']); ?></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="badge bg-warning"><?php echo htmlspecialchars(ucfirst($task['status'])); ?></span>
                                    <small>Assigned to: <?php echo htmlspecialchars($task['assigned_to_name']); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <!-- KONTEN UNIK HALAMAN BERAKHIR DI SINI -->
        </main>
    </div>

    <!-- Tombol Melayang (Floating Action Button) -->
    <div class="fab-container">
        <button class="btn btn-primary btn-lg rounded-circle">
            <i class="fas fa-plus"></i>
        </button>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/modern-dashboard.js"></script>
</body>
</html>
