<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
require_once '../config.php';

// --- LOGIKA TAMBAH TUGAS (DIMODIFIKASI UNTUK MULTI-USER) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_task'])) {
    $title = trim($_POST['task_title']);
    $project_id = (int)$_POST['project_id'];
    $assigned_users = $_POST['assigned_to']; // Ini sekarang adalah array
    $due_date = $_POST['due_date'];
    $status = $_POST['status'];
    $created_by = $_SESSION['user_id'];

    if (!empty($title) && $project_id > 0 && !empty($assigned_users)) {
        // Mulai transaksi
        $conn->begin_transaction();
        try {
            // 1. Insert ke tabel tasks (tanpa assigned_to)
            $stmt_task = $conn->prepare("INSERT INTO tasks (title, project_id, due_date, status, created_by) VALUES (?, ?, ?, ?, ?)");
            $stmt_task->bind_param("sisss", $title, $project_id, $due_date, $status, $created_by);
            $stmt_task->execute();

            // 2. Dapatkan ID tugas yang baru dibuat
            $new_task_id = $conn->insert_id;

            // 3. Insert ke tabel task_assignments untuk setiap user yang dipilih
            $stmt_assign = $conn->prepare("INSERT INTO task_assignments (task_id, user_id) VALUES (?, ?)");
            foreach ($assigned_users as $user_id) {
                $stmt_assign->bind_param("ii", $new_task_id, $user_id);
                $stmt_assign->execute();
            }

            // Jika semua berhasil, commit transaksi
            $conn->commit();
            header("Location: tasks.php");
            exit();

        } catch (Exception $e) {
            // Jika ada error, batalkan semua perubahan
            $conn->rollback();
            $error_message = "Gagal menambahkan tugas: " . $e->getMessage();
        }
    }
}

// --- LOGIKA HAPUS TUGAS (BARU) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_task'])) {
    $task_id = (int)$_POST['task_id'];
    if ($task_id > 0) {
        $stmt = $conn->prepare("DELETE FROM tasks WHERE id = ?");
        $stmt->bind_param("i", $task_id);
        if ($stmt->execute()) {
            header("Location: tasks.php");
            exit();
        }
    }
}

// --- Mengambil data untuk list tugas (DIMODIFIKASI DENGAN GROUP_CONCAT) ---
$query_tasks = "SELECT 
                    t.*, 
                    p.name as project_name, 
                    (SELECT GROUP_CONCAT(u.username SEPARATOR ', ') 
                     FROM task_assignments ta
                     JOIN users u ON ta.user_id = u.id
                     WHERE ta.task_id = t.id) as assigned_to_names
                FROM tasks t 
                LEFT JOIN projects p ON t.project_id = p.id
                ORDER BY t.due_date ASC";
$tasks_result = $conn->query($query_tasks);

// Ambil data projects dan users untuk dropdown di modal
$projects_result = $conn->query("SELECT id, name FROM projects ORDER BY name ASC");
$projects_options = $projects_result->fetch_all(MYSQLI_ASSOC);
$users_result = $conn->query("SELECT id, username FROM users ORDER BY username ASC");
$users_options = $users_result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/modern-styles.css">
    <style>
        .fab-container { position: fixed; bottom: 30px; right: 30px; z-index: 1000; }
        .card-title-container { display: flex; justify-content: space-between; align-items: center; }
        .delete-btn { cursor: pointer; color: #6c757d; }
        .delete-btn:hover { color: #dc3545; }
    </style>
</head>
<body>
    <div class="modern-wrapper">
        <?php include '../includes/sidebar.php'; ?>
        <main class="main-content">
            <header class="modern-header">
                <div class="header-left">
                    <button class="menu-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <h1 class="h4 mb-0">Tasks</h1>
                </div>
                <?php include '../includes/header.php'; ?>
            </header>
            <div class="container-fluid p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="h5 mb-0">All Tasks</h2>
                </div>
                <div class="row">
                    <?php while ($task = $tasks_result->fetch_assoc()): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <div class="card-title-container">
                                    <h5 class="card-title"><?php echo htmlspecialchars($task['title']); ?></h5>
                                    <span class="delete-btn" data-bs-toggle="modal" data-bs-target="#deleteTaskModal" data-task-id="<?php echo $task['id']; ?>" data-task-title="<?php echo htmlspecialchars($task['title']); ?>">
                                        <i class="fas fa-trash-can"></i>
                                    </span>
                                </div>
                                <p class="card-text text-muted">Project: <?php echo htmlspecialchars($task['project_name'] ?? 'N/A'); ?></p>
                                <p class="card-text"><small>Due: <?php echo date('d M Y', strtotime($task['due_date'])); ?></small></p>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="badge bg-warning text-dark"><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $task['status']))); ?></span>
                                    <small>Assigned to: <?php echo htmlspecialchars($task['assigned_to_names'] ?? 'N/A'); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </main>
    </div>

    <div class="fab-container">
        <button class="btn btn-primary btn-lg rounded-circle" data-bs-toggle="modal" data-bs-target="#addTaskModal">
            <i class="fas fa-plus"></i>
        </button>
    </div>

    <div class="modal fade" id="addTaskModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Task</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="tasks.php">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="taskTitle" class="form-label">Task Title</label>
                            <input type="text" class="form-control" id="taskTitle" name="task_title" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="projectId" class="form-label">Project</label>
                                <select class="form-select" id="projectId" name="project_id" required>
                                    <option value="">Select Project...</option>
                                    <?php foreach ($projects_options as $project): ?>
                                        <option value="<?php echo $project['id']; ?>"><?php echo htmlspecialchars($project['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="assignedTo" class="form-label">Assign To (bisa pilih lebih dari satu)</label>
                                <select class="form-select" id="assignedTo" name="assigned_to[]" required multiple size="5">
                                    <?php foreach ($users_options as $user): ?>
                                        <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="dueDate" class="form-label">Due Date</label>
                                <input type="date" class="form-control" id="dueDate" name="due_date" required>
                            </div>
                             <div class="col-md-6 mb-3">
                                <label for="taskStatus" class="form-label">Status</label>
                                <select class="form-select" id="taskStatus" name="status" required>
                                    <option value="to_do">To Do</option>
                                    <option value="in_progress">In Progress</option>
                                    <option value="done">Done</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_task" class="btn btn-primary">Create Task</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deleteTaskModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="tasks.php">
                    <div class="modal-body">
                        <p>Are you sure you want to delete the task "<strong id="deleteTaskTitle"></strong>"?</p>
                        <input type="hidden" name="task_id" id="deleteTaskId">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="delete_task" class="btn btn-danger">Delete Task</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/modern-dashboard.js"></script>
    <script>
    // SCRIPT BARU UNTUK MODAL HAPUS TUGAS
    document.addEventListener('DOMContentLoaded', function() {
        const deleteTaskModal = document.getElementById('deleteTaskModal');
        deleteTaskModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const taskId = button.getAttribute('data-task-id');
            const taskTitle = button.getAttribute('data-task-title');
            
            const modalTitle = deleteTaskModal.querySelector('#deleteTaskTitle');
            const modalInput = deleteTaskModal.querySelector('#deleteTaskId');
            
            modalTitle.textContent = taskTitle;
            modalInput.value = taskId;
        });
    });
    </script>
</body>
</html>