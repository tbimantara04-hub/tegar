<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
// PERBAIKAN: Path ke config.php yang benar
require_once '../config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Files - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <!-- PERBAIKAN: Menggunakan CSS yang konsisten -->
    <link rel="stylesheet" href="../assets/css/modern-styles.css" />
    <!-- Menambahkan CSS untuk tombol melayang -->
    <style>
        .fab-container {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div class="modern-wrapper">
        <!-- Memanggil Sidebar -->
        <?php include '../includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Memanggil Header -->
            <header class="modern-header">
                <div class="header-left">
                    <button class="menu-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
                    <h1 class="h4 mb-0">Files</h1>
                </div>
                <?php include '../includes/header.php'; ?>
            </header>

            <!-- Konten unik halaman -->
            <div class="container-fluid p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="h5 mb-0">All Files</h2>
                </div>

                <div class="row" id="filesGrid">
                    <?php
                    $stmt = $conn->prepare("SELECT f.*, u.username as uploaded_by_name FROM files f LEFT JOIN users u ON f.uploaded_by = u.id ORDER BY f.created_at DESC");
                    $stmt->execute();
                    $result = $stmt->get_result();

                    while ($file = $result->fetch_assoc()):
                    ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($file['original_name']); ?></h5>
                                <p class="card-text text-muted"><?php echo htmlspecialchars(substr($file['description'], 0, 100)) . '...'; ?></p>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="badge bg-secondary"><?php echo htmlspecialchars($file['file_type']); ?></span>
                                    <small>By: <?php echo htmlspecialchars($file['uploaded_by_name']); ?></small>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent border-top-0">
                                <a href="../uploads/<?php echo urlencode($file['filename']); ?>" class="btn btn-sm btn-outline-primary" download>
                                    <i class="fas fa-download"></i> Download
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Tombol Melayang (Floating Action Button) -->
    <div class="fab-container">
        <button class="btn btn-primary btn-lg rounded-circle" data-bs-toggle="modal" data-bs-target="#uploadFileModal">
            <i class="fas fa-upload"></i>
        </button>
    </div>

    <!-- Upload File Modal -->
    <div class="modal fade" id="uploadFileModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Upload New File</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="uploadFileForm" enctype="multipart/form-data" method="POST" action="../api/upload.php">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="fileInput" class="form-label">Select File</label>
                            <input type="file" class="form-control" id="fileInput" name="file" required />
                        </div>
                        <div class="mb-3">
                            <label for="fileDescription" class="form-label">Description</label>
                            <textarea class="form-control" id="fileDescription" name="description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Upload</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/modern-dashboard.js"></script>
</body>
</html>
