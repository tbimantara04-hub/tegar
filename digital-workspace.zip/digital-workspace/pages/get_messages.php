<?php
session_start();
require_once '../config.php';

// Atur header sebagai JSON di paling atas untuk konsistensi.
header('Content-Type: application/json');

// Validasi input di awal
// Pastikan user sudah login dan ID lawan chat valid (angka dan bukan nol).
if (!isset($_SESSION['user_id']) || !isset($_GET['user_id']) || !filter_var($_GET['user_id'], FILTER_VALIDATE_INT) || $_GET['user_id'] < 1) {
    // Jika tidak valid, kirim array JSON kosong dan hentikan eksekusi.
    echo json_encode([]);
    exit();
}

// Simpan variabel dengan aman
$currentUserId = $_SESSION['user_id'];
$chatWithUserId = (int)$_GET['user_id'];

// Logika utama dalam blok try-catch untuk menangani error database.
try {
    // Siapkan query SQL untuk mengambil percakapan.
    $stmt = $conn->prepare(
        "SELECT m.sender_id, m.message_content, m.created_at, u.username 
         FROM messages m 
         JOIN users u ON m.sender_id = u.id
         WHERE (m.sender_id = ? AND m.receiver_id = ?) 
            OR (m.sender_id = ? AND m.receiver_id = ?) 
         ORDER BY m.created_at ASC"
    );

    // Bind parameter ke query
    $stmt->bind_param("iiii", $currentUserId, $chatWithUserId, $chatWithUserId, $currentUserId);

    // Eksekusi query
    $stmt->execute();

    // Ambil hasilnya
    $result = $stmt->get_result();

    // Ambil semua baris data sekaligus ke dalam array.
    $messages = $result->fetch_all(MYSQLI_ASSOC);
    
    // Tutup statement setelah selesai
    $stmt->close();

} catch (Exception $e) {
    // Jika terjadi error, pastikan kita mengirim array kosong.
    $messages = []; 
}

// Kirim hasil (baik berisi data atau array kosong) sebagai JSON.
echo json_encode($messages);

// Tutup koneksi database
$conn->close();
?>