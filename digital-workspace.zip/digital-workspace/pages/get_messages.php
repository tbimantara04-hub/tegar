<?php
session_start();
require_once '../config.php'; // Sesuaikan path ke file config.php

// 1. Pindahkan header ke bagian paling atas.
// Ini memastikan browser selalu tahu bahwa responsnya adalah JSON.
header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !isset($_GET['user_id'])) {
    // Jika ada error, cukup kirim array JSON kosong agar tidak merusak JavaScript.
    echo json_encode([]);
    exit();
}

$currentUserId = $_SESSION['user_id'];
$chatWithUserId = (int)$_GET['user_id']; // Konversi ke integer untuk keamanan

$messages = []; // Inisialisasi array di awal

try {
    $stmt = $conn->prepare("SELECT m.sender_id, m.message_content, m.created_at, u.username 
                             FROM messages m 
                             JOIN users u ON m.sender_id = u.id
                             WHERE (m.sender_id = ? AND m.receiver_id = ?) 
                                OR (m.sender_id = ? AND m.receiver_id = ?) 
                             ORDER BY m.created_at ASC");
    
    // Periksa apakah prepare() berhasil
    if ($stmt === false) {
        // Jika query gagal, kirim array kosong dan jangan lanjutkan.
        echo json_encode([]);
        exit();
    }

    $stmt->bind_param("iiii", $currentUserId, $chatWithUserId, $chatWithUserId, $currentUserId);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    
    $stmt->close();

} catch (Exception $e) {
    // Jika ada error apapun selama proses database, kita tetap kirim array kosong.
    // Ini lebih aman untuk sisi front-end.
    $messages = []; 
}

echo json_encode($messages);

$conn->close();
?>