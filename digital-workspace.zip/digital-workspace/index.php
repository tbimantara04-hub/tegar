<?php
session_start();
// Path yang benar ke config.php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// --- LOGIKA UNTUK MENGAMBIL NOTIFIKASI BARU ---
// PERBAIKAN: Menggunakan data notifikasi dinamis untuk dropdown
$notifications = [
    [
        'icon' => 'fa-project-diagram',
        'color' => 'text-primary',
        'title' => 'New project created',
        'body' => '"Website Redesign" was just created by Satria Tegar.',
        'time' => '15 minutes ago',
        'link' => 'pages/projects.php' // Tautan ke halaman proyek
    ],
    [
        'icon' => 'fa-tasks',
        'color' => 'text-success',
        'title' => 'Task Completed',
        'body' => 'Sudiro Sigit completed the task "Review client report".',
        'time' => '1 hour ago',
        'link' => 'pages/tasks.php' // Tautan ke halaman tugas
    ],
    [
        'icon' => 'fa-file-alt',
        'color' => 'text-warning',
        'title' => 'New File Uploaded',
        'body' => 'Tipando uploaded "Q4_Report.pdf".',
        'time' => '3 hours ago',
        'link' => 'pages/files.php' // Tautan ke halaman file
    ]
];


// --- LOGIKA UNTUK MENGAMBIL JUMLAH DATA STATISTIK ---
// Mengambil jumlah proyek aktif (misalnya, yang statusnya bukan 'completed')
$project_count_result = $conn->query("SELECT COUNT(*) as count FROM projects WHERE status != 'completed'");
$project_count = $project_count_result->fetch_assoc()['count'];

// Mengambil jumlah tugas untuk hari ini
$task_count_result = $conn->query("SELECT COUNT(*) as count FROM tasks WHERE DATE(due_date) = CURDATE()");
$task_count = $task_count_result->fetch_assoc()['count'];

// Mengambil jumlah file
$file_count_result = $conn->query("SELECT COUNT(*) as count FROM files");
$file_count = $file_count_result->fetch_assoc()['count'];

// Mengambil jumlah anggota tim (users)
$team_count_result = $conn->query("SELECT COUNT(*) as count FROM users");
$team_count = $team_count_result->fetch_assoc()['count'];

// --- LOGIKA UNTUK MENGAMBIL DATA WIDGETS ---
// Mengambil 3 tugas terbaru
$recent_tasks = $conn->query("SELECT * FROM tasks ORDER BY created_at DESC LIMIT 3");

// Mengambil 3 file terbaru
$recent_files = $conn->query("SELECT * FROM files ORDER BY created_at DESC LIMIT 3");

// --- PERBAIKAN ERROR ---
// Query di bawah ini dinonaktifkan karena tabel 'team_activities' tidak ada di database.
// Untuk mengaktifkan kembali fitur ini, buat tabel 'team_activities' dengan kolom seperti: id, user_id, activity, created_at.
$team_activities = []; // Inisialisasi sebagai array kosong untuk mencegah error.
// $team_activities = $conn->query("SELECT u.username, a.activity, a.created_at FROM team_activities a JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT 3");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/modern-styles.css">
    <style>
        .stat-card-link {
            display: block;
            text-decoration: none;
            color: inherit;
            transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
        }
        .stat-card-link:hover .stat-card {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        .notification-dropdown-menu {
            width: 320px;
            padding: 0;
            border-radius: 0.5rem;
        }
        .notification-dropdown-menu .dropdown-header {
            font-weight: 600;
            padding: 0.75rem 1rem;
        }
        .notification-dropdown-menu .dropdown-item {
            padding: 0.75rem 1rem;
            white-space: normal;
        }
        .notification-dropdown-menu .dropdown-item:hover {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    <nav class="modern-sidebar">
        <div class="sidebar-header">
            <a href="#" class="brand-logo">
                <i class="fas fa-rocket"></i>
                <span>DWS</span>
            </a>
        </div>
        
        <div class="user-profile">
            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['username']); ?>&background=3b82f6&color=fff" alt="User" class="user-avatar">
            <div class="user-info">
                <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                <div class="user-role"><?php echo htmlspecialchars($_SESSION['role']); ?></div>
            </div>
        </div>
        
        <ul class="sidebar-nav">
            <li class="nav-item">
                <a href="index.php" class="nav-link active">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="pages/projects.php" class="nav-link">
                    <i class="fas fa-project-diagram"></i>
                    <span>Projects</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="pages/tasks.php" class="nav-link">
                    <i class="fas fa-tasks"></i>
                    <span>Tasks</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="pages/files.php" class="nav-link">
                    <i class="fas fa-folder"></i>
                    <span>Files</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="pages/messages.php" class="nav-link">
                    <i class="fas fa-comments"></i>
                    <span>Messages</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="pages/calendar.php" class="nav-link">
                    <i class="fas fa-calendar"></i>
                    <span>Calendar</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="pages/employees.php" class="nav-link">
                    <i class="fas fa-users"></i>
                    <span>Team</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="pages/profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
    </nav>

    <main class="main-content">
        <header class="modern-header">
            <div class="header-left">
                <button class="menu-toggle" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="h4 mb-0">Dashboard</h1>
            </div>
            
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" class="search-input" placeholder="Search...">
                </div>
                
                <div class="dropdown">
                    <button class="notification-btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge"><?php echo count($notifications); ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end notification-dropdown-menu">
                        <li class="dropdown-header">Notifications</li>
                        <li><hr class="dropdown-divider m-0"></li>
                        <?php foreach ($notifications as $notification): ?>
                        <li>
                            <a class="dropdown-item d-flex align-items-start" href="<?php echo $notification['link']; ?>">
                                <i class="fas <?php echo $notification['icon']; ?> <?php echo $notification['color']; ?> me-3 mt-1"></i>
                                <div>
                                    <strong><?php echo $notification['title']; ?></strong>
                                    <div class="small text-muted"><?php echo $notification['body']; ?></div>
                                    <div class="small text-muted"><?php echo $notification['time']; ?></div>
                                </div>
                            </a>
                        </li>
                        <li><hr class="dropdown-divider m-0"></li>
                        <?php endforeach; ?>
                        <li><a class="dropdown-item text-center small py-2" href="pages/notifications.php">View all notifications</a></li>
                    </ul>
                </div>
                
                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['username']); ?>&background=3b82f6&color=fff" alt="Profile" class="rounded-circle me-2" width="32" height="32">
                        <?php echo htmlspecialchars($_SESSION['username']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="pages/profile.php">Profile</a></li>
                        <li><a class="dropdown-item" href="#">Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="auth/logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </header>

        <div class="container-fluid p-4">
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <a href="pages/projects.php" class="stat-card-link">
                        <div class="stat-card">
                            <i class="fas fa-project-diagram stat-icon"></i>
                            <div class="stat-value"><?php echo $project_count; ?></div>
                            <div class="stat-label">Active Projects</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="pages/tasks.php" class="stat-card-link">
                        <div class="stat-card success">
                            <i class="fas fa-tasks stat-icon"></i>
                            <div class="stat-value"><?php echo $task_count; ?></div>
                            <div class="stat-label">Tasks Today</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="pages/files.php" class="stat-card-link">
                        <div class="stat-card warning">
                            <i class="fas fa-folder stat-icon"></i>
                            <div class="stat-value"><?php echo $file_count; ?></div>
                            <div class="stat-label">Files Shared</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="pages/employees.php" class="stat-card-link">
                        <div class="stat-card danger">
                            <i class="fas fa-users stat-icon"></i>
                            <div class="stat-value"><?php echo $team_count; ?></div>
                            <div class="stat-label">Team Members</div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="modern-card">
                        <div class="card-header">
                            <h5 class="card-title">Recent Tasks</h5>
                        </div>
                        <div class="card-body">
                            <?php if($recent_tasks->num_rows > 0): ?>
                                <?php while($task = $recent_tasks->fetch_assoc()): ?>
                                <div class="task-item d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($task['title']); ?></h6>
                                        <small class="text-muted">Due: <?php echo date("M d", strtotime($task['due_date'])); ?></small>
                                    </div>
                                    <span class="badge 
                                        <?php 
                                            if ($task['status'] == 'pending') echo 'bg-warning';
                                            elseif ($task['status'] == 'in_progress') echo 'bg-info';
                                            else echo 'bg-success';
                                        ?>
                                    "><?php echo ucfirst(str_replace('_', ' ', $task['status'])); ?></span>
                                </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-center text-muted">No recent tasks.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 mb-4">
                    <div class="modern-card">
                        <div class="card-header">
                            <h5 class="card-title">Recent Files</h5>
                        </div>
                        <div class="card-body">
                             <?php if($recent_files->num_rows > 0): ?>
                                <?php while($file = $recent_files->fetch_assoc()): ?>
                                <div class="file-item d-flex align-items-center mb-3">
                                    <i class="fas fa-file-alt text-secondary me-3"></i>
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($file['filename']); ?></h6>
                                        <small class="text-muted">Modified <?php echo date("M d, Y", strtotime($file['created_at'])); ?></small>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-center text-muted">No recent files.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Sidebar toggle functionality
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.modern-sidebar').classList.toggle('collapsed');
            document.querySelector('.main-content').classList.toggle('expanded');
        });

        // Add fade-in animation to cards
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.modern-card, .stat-card').forEach(card => {
            observer.observe(card);
        });
    </script>
</body>
</html>