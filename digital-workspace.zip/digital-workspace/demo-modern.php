<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Dashboard Demo - Digital Workspace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/modern-styles.css">
</head>
<body>
    <!-- Modern Sidebar -->
    <nav class="modern-sidebar">
        <div class="sidebar-header">
            <a href="#" class="brand-logo">
                <i class="fas fa-rocket"></i>
                <span>Workspace</span>
            </a>
        </div>
        
        <div class="user-profile">
            <img src="https://ui-avatars.com/api/?name=John+Doe&background=3b82f6&color=fff" alt="User" class="user-avatar">
            <div class="user-info">
                <div class="user-name">John Doe</div>
                <div class="user-role">Admin</div>
            </div>
        </div>
        
        <ul class="sidebar-nav">
            <li class="nav-item">
                <a href="#" class="nav-link active">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-project-diagram"></i>
                    <span>Projects</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-tasks"></i>
                    <span>Tasks</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-folder"></i>
                    <span>Files</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-comments"></i>
                    <span>Messages</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-calendar"></i>
                    <span>Calendar</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-users"></i>
                    <span>Team</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
        <div class="sidebar-footer">
            <a href="auth/logout.php" class="btn btn-danger w-100">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Modern Header -->
        <header class="modern-header">
            <div class="header-left">
                <button class="menu-toggle" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="h4 mb-0">Dashboard</h1>
            </div>
            <div class="header-right">
                <div class="search-box">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" class="search-input" placeholder="Search...">
                </div>
                <button class="notification-btn">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </button>
            </div>
        </header>

        <!-- Dashboard Content -->
        <div class="container-fluid p-4">
            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <i class="fas fa-project-diagram stat-icon"></i>
                        <div class="stat-value">8</div>
                        <div class="stat-label">Active Projects</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card success">
                        <i class="fas fa-tasks stat-icon"></i>
                        <div class="stat-value">12</div>
                        <div class="stat-label">Tasks Today</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card warning">
                        <i class="fas fa-folder stat-icon"></i>
                    <div class="stat-value">24</div>
                    <div class="stat-label">Files Shared</div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stat-card danger">
                    <i class="fas fa-users stat-icon"></i>
                    <div class="stat-value">15</div>
                    <div class="stat-label">Team Members</div>
                </div>
            </div>
        </div>

        <!-- Dashboard Widgets -->
        <div class="row">
            <!-- Recent Tasks -->
            <div class="col-md-6 mb-4">
                <div class="modern-card">
                    <div class="card-header">
                        <h5 class="card-title">Recent Tasks</h5>
                    </div>
                    <div class="card-body">
                        <div class="task-item d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 class="mb-1">Complete project proposal</h6>
                                <small class="text-muted">Due: Tomorrow</small>
                            </div>
                            <span class="badge bg-warning">Pending</span>
                        </div>
                        <div class="task-item d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 class="mb-1">Review client feedback</h6>
                                <small class="text-muted">Due: Today</small>
                            </div>
                            <span class="badge bg-info">In Progress</span>
                        </div>
                        <div class="task-item d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1">Update documentation</h6>
                                <small class="text-muted">Due: This week</small>
                            </div>
                            <span class="badge bg-success">Completed</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Files -->
            <div class="col-md-6 mb-4">
                <div class="modern-card">
                    <div class="card-header">
                        <h5 class="card-title">Recent Files</h5>
                    </div>
                    <div class="card-body">
                        <div class="file-item d-flex align-items-center mb-3">
                            <i class="fas fa-file-pdf text-danger me-3"></i>
                            <div>
                                <h6 class="mb-1">Project_Proposal.pdf</h6>
                                <small class="text-muted">Modified 2 hours ago</small>
                            </div>
                        </div>
                        <div class="file-item d-flex align-items-center mb-3">
                            <i class="fas fa-file-excel text-success me-3"></i>
                            <div>
                                <h6 class="mb-1">Budget_Report.xlsx</h6>
                            <small class="text-muted">Modified 1 day ago</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Team Activity -->
        <div class="row">
            <div class="col-12">
                <div class="modern-card">
                    <div class="card-header">
                        <h5 class="card-title">Team Activity</h5>
                    </div>
            <div class="card-body">
                <div class="activity-feed">
                    <div class="activity-item d-flex mb-3">
                        <img src="https://ui-avatars.com/api/?name=Sarah+Johnson&background=10b981&color=fff" alt="User" class="rounded-circle me-3" width="40" height="40">
                        <div>
                            <h6 class="mb-1">Sarah Johnson</h6>
                            <p class="mb-1">Completed task "Review client proposal"</p>
                            <small class="text-muted">2 hours ago</small>
                        </div>
                    </div>
                    <div class="activity-item d-flex mb-3">
                        <img src="https://ui-avatars.com/api/?name=Mike+Chen&background=3b82f6&color=fff" alt="User" class="rounded-circle me-3" width="40" height="40">
                        <div>
                            <h6 class="mb-1">Mike Chen</h6>
                            <p class="mb-1">Uploaded new file "Q4_Report.pdf"</p>
                            <small class="text-muted">4 hours ago</small>
                        </div>
                    </div>
                    <div class="activity-item d-flex">
                        <img src="https://ui-avatars.com/api/?name=Emma+Wilson&background=f59e0b&color=fff" alt="User" class="rounded-circle me-3" width="40" height="40">
                        <div>
                            <h6 class="mb-1">Emma Wilson</h6>
                        <p class="mb-1">Created new project "Website Redesign"</p>
                        <small class="text-muted">6 hours ago</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
</body>
</html>
